package com.gujju.voiceagent

/** Tiny bridge so the background service can show status/log in the app when it is open. */
object Bus {
    @Volatile var onStatus: ((String) -> Unit)? = null
    @Volatile var onLog: ((String) -> Unit)? = null
    @Volatile var lastStatus = "Off. Turn on the switch below."
    @Volatile var running = false
    val logBuffer = StringBuilder()

    fun status(s: String) { lastStatus = s; onStatus?.invoke(s) }
    fun log(who: String, msg: String) {
        val l = "$who: $msg\n\n"
        synchronized(logBuffer) {
            logBuffer.append(l)
            if (logBuffer.length > 20000) logBuffer.delete(0, 5000)
        }
        onLog?.invoke(l)
    }
}
