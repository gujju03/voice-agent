package com.gujju.voiceagent

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.*
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors

/** Runs the whole offline agent in the background (foreground service with a notification). */
class VoiceService : Service(), RecognitionListener {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_TALK = "talk"
        const val ACTION_RELOAD = "reload"
        const val CHANNEL = "voice_agent"
        const val WAKE = "hey assistant"   // must be words that exist in the Vosk vocabulary
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var speech: SpeechService? = null
    private var llm: LlmInference? = null
    private var voskModel: Model? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private lateinit var commands: Commands
    private var wakeLock: PowerManager.WakeLock? = null

    private enum class Mode { IDLE, WAKE, COMMAND }
    @Volatile private var mode = Mode.IDLE
    @Volatile private var busy = false
    @Volatile private var ready = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Voice Agent", NotificationManager.IMPORTANCE_LOW))
        commands = Commands(this) { i ->
            main.post { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
        }
        tts = TextToSpeech(this) { ttsReady = it == TextToSpeech.SUCCESS }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { afterSpeaking() }
            override fun onDone(id: String?) { afterSpeaking() }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { cleanup(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            ACTION_TALK -> { if (ready && !busy) main.post { startCommand() } }
            ACTION_RELOAD -> loadModels()
            else -> {
                showNotification()
                if (!Bus.running) {
                    Bus.running = true
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voiceagent:listen").apply { acquire() }
                    loadModels()
                }
            }
        }
        return START_STICKY
    }

    private fun showNotification() {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Voice Agent is listening")
            .setContentText("Say \"$WAKE\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    // ---------- models ----------
    private fun loadModels() = worker.execute {
        ready = false
        val latch = CountDownLatch(1)
        main.post { speech?.stop(); speech?.shutdown(); speech = null; mode = Mode.IDLE; latch.countDown() }
        latch.await()
        llm?.close(); llm = null; voskModel?.close(); voskModel = null

        val dir = getExternalFilesDir(null)!!
        val voskDir = File(dir, "vosk-model"); val gemma = File(dir, "gemma.task")
        if (!voskDir.exists() || !gemma.exists()) {
            Bus.running = false
            Bus.status("Models missing. Open the app and tap the two Import buttons.")
            main.post { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            return@execute
        }
        try {
            Bus.status("Loading speech model…")
            voskModel = Model(voskDir.absolutePath)
            Bus.status("Loading language model (30-60 s first time)…")
            llm = LlmInference.createFromOptions(this, LlmInference.LlmInferenceOptions.builder()
                .setModelPath(gemma.absolutePath).setMaxTokens(384).build())
            ready = true
            main.post { startWake() }
        } catch (e: Exception) { Bus.status("Load error: ${e.message}") }
    }

    // ---------- listen ----------
    private fun startWake() {
        val m = voskModel ?: return
        try {
            speech?.stop(); speech?.shutdown()
            mode = Mode.WAKE
            speech = SpeechService(Recognizer(m, 16000f, "[\"$WAKE\", \"[unk]\"]"), 16000f)
                .also { it.startListening(this) }
            Bus.status("Waiting for \"$WAKE\"…")
        } catch (e: Exception) { Bus.status("Mic error: ${e.message}") }
    }

    private fun startCommand() {
        val m = voskModel ?: return
        if (busy) return
        try {
            speech?.stop(); speech?.shutdown()
            mode = Mode.COMMAND
            ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            speech = SpeechService(Recognizer(m, 16000f), 16000f).also { it.startListening(this, 8000) }
            Bus.status("Listening…")
        } catch (e: Exception) { Bus.status("Mic error: ${e.message}") }
    }

    override fun onPartialResult(hypothesis: String?) {
        if (mode != Mode.WAKE) return
        if (WAKE in JSONObject(hypothesis ?: return).optString("partial")) startCommand()
    }

    override fun onResult(hypothesis: String?) {
        val text = JSONObject(hypothesis ?: return).optString("text").trim()
        when (mode) {
            Mode.WAKE -> if (WAKE in text) startCommand()
            Mode.COMMAND -> {
                if (text.isEmpty() || busy) return
                busy = true
                speech?.stop(); speech?.shutdown(); speech = null
                mode = Mode.IDLE
                Bus.log("You", text); Bus.status("Thinking…")
                worker.execute { respond(text) }
            }
            Mode.IDLE -> {}
        }
    }
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(e: Exception?) { Bus.status("Mic error: ${e?.message}") }
    override fun onTimeout() { speech?.shutdown(); speech = null; mode = Mode.IDLE; startWake() }

    // ---------- think + speak ----------
    private fun respond(userText: String) {
        val reply = commands.handle(userText) ?: try {
            val prompt = "<start_of_turn>user\n" +
                "You are a helpful voice assistant. Answer in 1-3 short spoken sentences, " +
                "no markdown. Reply in the same language the user used.\n\n" +
                "$userText<end_of_turn>\n<start_of_turn>model\n"
            llm!!.generateResponse(prompt).trim()
        } catch (e: Exception) { "Sorry, something went wrong." }
        Bus.log("Agent", reply)
        speak(reply)
    }

    private fun speak(text: String) {
        if (!ttsReady) { afterSpeaking(); return }
        val hindi = text.any { it in '\u0900'..'\u097F' }
        tts.language = if (hindi) Locale("hi", "IN") else Locale.US
        Bus.status("Speaking…")
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply")
    }

    private fun afterSpeaking() { main.post { busy = false; if (Bus.running && ready) startWake() } }

    // ---------- shutdown ----------
    private fun cleanup() {
        Bus.running = false; ready = false
        speech?.stop(); speech?.shutdown(); speech = null; mode = Mode.IDLE
        tts.stop(); llm?.close(); llm = null; voskModel?.close(); voskModel = null
        wakeLock?.let { if (it.isHeld) it.release() }; wakeLock = null
        Bus.status("Off. Turn on the switch below.")
    }

    override fun onDestroy() {
        cleanup(); tts.shutdown(); super.onDestroy()
    }
}
