package com.gujju.voiceagent

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/** Offline voice commands. Returns a spoken reply, or null to let the LLM answer. */
class Commands(private val ctx: Context, private val launch: (Intent) -> Unit) {

    private val notesFile get() = File(ctx.getExternalFilesDir(null), "notes.txt")

    /** Action waiting for a "yes" (e.g. a call). */
    private var pending: (() -> String)? = null
    val awaitingReply get() = pending != null
    fun clearPending() { pending = null }

    fun handle(raw: String): String? {
        val s = raw.lowercase().trim()

        // ---- yes / no to a pending confirmation ----
        pending?.let { p ->
            pending = null
            if (Regex("\\b(yes|yeah|yep|confirm|okay|ok|sure|do it)\\b").containsMatchIn(s)) return p()
            if (Regex("\\b(no|nope|cancel|stop|never mind)\\b").containsMatchIn(s)) return "Cancelled."
        }

        return when {
            "set" in s && "alarm" in s -> alarm(s)
            "timer" in s -> timer(s)
            s.startsWith("note ") || "take a note" in s || s.startsWith("remember ") -> addNote(s)
            "read my notes" in s || "read notes" in s -> readNotes()
            "clear my notes" in s || "clear notes" in s -> { notesFile.delete(); "Notes cleared." }
            Regex("^(open|launch|start)\\s+\\S+").containsMatchIn(s) ->
                openApp(s.replace(Regex("^(open|launch|start)\\s+"), "").replace("please", "").trim())
            Regex("^(call|phone|ring|dial)\\s+\\S+").containsMatchIn(s) ->
                call(s.replace(Regex("^(call|phone|ring|dial)\\s+"), "").replace("please", "").trim())
            "what time" in s || "समय" in s ->
                "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            "what date" in s || "today's date" in s ->
                "Today is " + SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            else -> null
        }
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    // ---- open an app: "open whatsapp" ----
    private fun openApp(name: String): String {
        val t = norm(name)
        if (t.isEmpty()) return "Which app?"
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == t }
            ?: apps.firstOrNull {
                val l = norm(it.loadLabel(pm).toString())
                l.isNotEmpty() && (l.contains(t) || (l.length >= 4 && t.contains(l)))
            }
            ?: return "I couldn't find an app called $name."
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "I can't open that app."
        launch(i)
        return "Opening ${hit.loadLabel(pm)}."
    }

    // ---- call a contact (asks for confirmation) ----
    private fun call(name: String): String {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return "I need contacts permission. Open the app and tap Allow contacts and calls."
        val hit = findContact(name) ?: return "I couldn't find $name in your contacts."
        val (display, number) = hit
        pending = {
            val canCall = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            val uri = Uri.parse("tel:" + Uri.encode(number))
            launch(Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
            "Calling $display."
        }
        return "Call $display? Say yes to confirm."
    }

    private fun findContact(name: String): Pair<String, String>? {
        val target = norm(name)
        if (target.isEmpty()) return null
        var best: Pair<String, String>? = null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                val nn = norm(n)
                if (nn == target) return Pair(n, num)
                if (best == null && nn.isNotEmpty() && (nn.contains(target) || (nn.length >= 3 && target.contains(nn))))
                    best = Pair(n, num)
            }
        }
        return best
    }

    // ---- alarm: "set an alarm for seven thirty a m" ----
    private fun alarm(s: String): String {
        val n = numbers(s)
        if (n.isEmpty()) return "What time should I set the alarm for?"
        var h = n[0]; val m = n.getOrElse(1) { 0 }
        val pm = Regex("\\bp m\\b|\\bpm\\b|evening|night|afternoon").containsMatchIn(s)
        val am = Regex("\\ba m\\b|\\bam\\b|morning").containsMatchIn(s)
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (h > 23 || m > 59) return "I didn't catch a valid time."
        launch(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Voice Agent")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        val label = SimpleDateFormat("h:mm a", Locale.US)
            .format(Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }.time)
        return "Alarm set for $label."
    }

    // ---- timer: "set a timer for five minutes" ----
    private fun timer(s: String): String {
        val n = numbers(s).firstOrNull() ?: 1
        val secs = when {
            "hour" in s -> n * 3600
            "second" in s -> n
            else -> n * 60
        }
        launch(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Timer started."
    }

    // ---- notes ----
    private fun addNote(s: String): String {
        val body = s.replace(Regex("^(take a note|note that|note|remember that|remember)\\s*"), "").trim()
        if (body.isEmpty()) return "What should I note?"
        val stamp = SimpleDateFormat("d MMM h:mm a", Locale.US).format(Date())
        notesFile.appendText("[$stamp] $body\n")
        return "Noted."
    }

    private fun readNotes(): String {
        val lines = if (notesFile.exists()) notesFile.readLines().takeLast(3) else emptyList()
        return if (lines.isEmpty()) "You have no notes."
        else "Your last notes: " + lines.joinToString(". ") { it.substringAfter("] ") }
    }

    // ---- spoken numbers -> ints ("seven thirty" -> [7, 30], "twenty five" -> [25]) ----
    private val units = listOf("zero","one","two","three","four","five","six","seven","eight","nine",
        "ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen")
    private val tens = mapOf("twenty" to 20,"thirty" to 30,"forty" to 40,"fifty" to 50)

    private fun numbers(s: String): List<Int> {
        val out = mutableListOf<Int>()
        val t = s.replace("o'clock", "").replace("an hour", "one hour")
            .replace("a minute", "one minute").split(Regex("\\s+"))
        var i = 0
        while (i < t.size) {
            val w = t[i]
            val d = w.toIntOrNull()
            when {
                d != null -> out.add(d)
                w in tens -> {
                    val nxt = t.getOrNull(i + 1)?.let { units.indexOf(it) } ?: -1
                    if (nxt in 1..9) { out.add(tens[w]!! + nxt); i++ } else out.add(tens[w]!!)
                }
                w in units -> out.add(units.indexOf(w))
            }
            i++
        }
        return out
    }
}
