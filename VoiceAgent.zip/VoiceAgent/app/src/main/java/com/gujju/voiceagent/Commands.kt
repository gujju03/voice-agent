package com.gujju.voiceagent

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/** Offline voice commands. Returns a spoken reply, or null to let the LLM answer. */
class Commands(private val ctx: Context, private val launch: (Intent) -> Unit) {

    private val notesFile get() = File(ctx.getExternalFilesDir(null), "notes.txt")

    fun handle(raw: String): String? {
        val s = raw.lowercase().trim()
        return when {
            "set" in s && "alarm" in s -> alarm(s)
            "timer" in s -> timer(s)
            s.startsWith("note ") || "take a note" in s || s.startsWith("remember ") -> addNote(s)
            "read my notes" in s || "read notes" in s -> readNotes()
            "clear my notes" in s || "clear notes" in s -> { notesFile.delete(); "Notes cleared." }
            "what time" in s || "समय" in s ->
                "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            "what date" in s || "today's date" in s ->
                "Today is " + SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            else -> null
        }
    }

    // ---- alarm: "set an alarm for seven thirty a m" ----
    private fun alarm(s: String): String {
        val n = numbers(s)
        if (n.isEmpty()) return "What time should I set the alarm for?"
        var h = n[0]; val m = n.getOrElse(1) { 0 }
        val pm = Regex("\\bp m\\b|\\bpm\\b|evening|night|afternoon").containsMatchIn(s)
        val am = Regex("\\ba m\\b|\\bam\\b|morning").containsMatchIn(s)
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (h > 23 || m > 59) return "I didn't catch a valid time."
        launch(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Voice Agent")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        val label = SimpleDateFormat("h:mm a", Locale.US)
            .format(Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }.time)
        return "Alarm set for $label."
    }

    // ---- timer: "set a timer for five minutes" ----
    private fun timer(s: String): String {
        val n = numbers(s).firstOrNull() ?: 1
        val secs = when {
            "hour" in s -> n * 3600
            "second" in s -> n
            else -> n * 60
        }
        launch(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Timer started."
    }

    // ---- notes ----
    private fun addNote(s: String): String {
        val body = s.replace(Regex("^(take a note|note that|note|remember that|remember)\\s*"), "").trim()
        if (body.isEmpty()) return "What should I note?"
        val stamp = SimpleDateFormat("d MMM h:mm a", Locale.US).format(Date())
        notesFile.appendText("[$stamp] $body\n")
        return "Noted."
    }

    private fun readNotes(): String {
        val lines = if (notesFile.exists()) notesFile.readLines().takeLast(3) else emptyList()
        return if (lines.isEmpty()) "You have no notes."
        else "Your last notes: " + lines.joinToString(". ") { it.substringAfter("] ") }
    }

    // ---- spoken numbers -> ints ("seven thirty" -> [7, 30], "twenty five" -> [25]) ----
    private val units = listOf("zero","one","two","three","four","five","six","seven","eight","nine",
        "ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen")
    private val tens = mapOf("twenty" to 20,"thirty" to 30,"forty" to 40,"fifty" to 50)

    private fun numbers(s: String): List<Int> {
        val out = mutableListOf<Int>()
        val t = s.replace("o'clock", "").replace("an hour", "one hour")
            .replace("a minute", "one minute").split(Regex("\\s+"))
        var i = 0
        while (i < t.size) {
            val w = t[i]
            val d = w.toIntOrNull()
            when {
                d != null -> out.add(d)
                w in tens -> {
                    val nxt = t.getOrNull(i + 1)?.let { units.indexOf(it) } ?: -1
                    if (nxt in 1..9) { out.add(tens[w]!! + nxt); i++ } else out.add(tens[w]!!)
                }
                w in units -> out.add(units.indexOf(w))
            }
            i++
        }
        return out
    }
}
