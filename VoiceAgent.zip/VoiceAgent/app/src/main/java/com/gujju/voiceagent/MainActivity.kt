package com.gujju.voiceagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/** Screen only: setup, import models, start/stop the background service. */
class MainActivity : AppCompatActivity() {

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var always: Switch
    private var ignoreSwitch = false
    private lateinit var btnContacts: Button
    private lateinit var btnOverlay: Button

    private val askContacts = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refreshButtons() }

    private val pickGemma = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { importFile(it, false) } }
    private val pickVosk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { importFile(it, true) } }
    private val askPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasMic()) startAgent() else { setSwitch(false); status.text = "Microphone permission needed" }
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun svc(action: String) = Intent(this, VoiceService::class.java).setAction(action)
    private fun startAgent() = ContextCompat.startForegroundService(this, svc(VoiceService.ACTION_START))
    private fun setSwitch(on: Boolean) { ignoreSwitch = true; always.isChecked = on; ignoreSwitch = false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val outer = ScrollView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        outer.addView(root)
        status = TextView(this).apply { textSize = 16f }
        log = TextView(this).apply { textSize = 15f; minLines = 6 }
        scroll = outer

        always = Switch(this).apply {
            text = "Always listening (works with app closed)\nSay \"hey assistant\""
            setOnCheckedChangeListener { _, on ->
                if (ignoreSwitch) return@setOnCheckedChangeListener
                if (on) {
                    val need = mutableListOf<String>()
                    if (!hasMic()) need += Manifest.permission.RECORD_AUDIO
                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity,
                            Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                        need += Manifest.permission.POST_NOTIFICATIONS
                    if (need.isEmpty()) startAgent() else askPerms.launch(need.toTypedArray())
                } else startService(svc(VoiceService.ACTION_STOP))
            }
        }
        btnContacts = Button(this).apply {
            setOnClickListener {
                askContacts.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
            }
        }
        btnOverlay = Button(this).apply {
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }

        root.addView(status)
        root.addView(always)
        root.addView(Button(this).apply {
            text = "🎤  Talk now"
            setOnClickListener {
                if (Bus.running) startService(svc(VoiceService.ACTION_TALK))
                else status.text = "Turn on the switch first"
            }
        })
        root.addView(Button(this).apply {
            text = "1. Import Gemma file (.task)"; setOnClickListener { pickGemma.launch(arrayOf("*/*")) } })
        root.addView(Button(this).apply {
            text = "2. Import Vosk model (.zip)"; setOnClickListener { pickVosk.launch(arrayOf("*/*")) } })
        root.addView(btnContacts)
        root.addView(btnOverlay)
        root.addView(log)
        setContentView(outer)
        refreshButtons()
    }

    private fun refreshButtons() {
        val c = hasPerm(Manifest.permission.READ_CONTACTS) && hasPerm(Manifest.permission.CALL_PHONE)
        btnContacts.text = "3. Allow contacts and calls" + if (c) "  ✓" else ""
        btnOverlay.text = "4. Allow opening apps in background" + if (Settings.canDrawOverlays(this)) "  ✓" else ""
    }
    private fun hasPerm(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun onStart() {
        super.onStart()
        refreshButtons()
        Bus.onStatus = { s -> runOnUiThread { status.text = s; setSwitch(Bus.running) } }
        Bus.onLog = { l -> runOnUiThread { log.append(l) } }
        status.text = Bus.lastStatus
        synchronized(Bus.logBuffer) { log.text = Bus.logBuffer.toString() }
        setSwitch(Bus.running)
    }

    override fun onStop() { super.onStop(); Bus.onStatus = null; Bus.onLog = null }

    // ---------- Import models from Downloads ----------
    private fun importFile(uri: Uri, isVosk: Boolean) = worker.execute {
        val dir = getExternalFilesDir(null)!!
        try {
            if (Bus.running) startService(svc(VoiceService.ACTION_STOP))
            if (!isVosk) {
                Bus.status("Copying Gemma file… please wait")
                val tmp = File(dir, "gemma.tmp")
                contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                File(dir, "gemma.task").delete(); tmp.renameTo(File(dir, "gemma.task"))
            } else {
                Bus.status("Unpacking speech model…")
                val out = File(dir, "vosk-model"); out.deleteRecursively(); out.mkdirs()
                ZipInputStream(contentResolver.openInputStream(uri)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val rel = e.name.substringAfter('/', "")
                        if (rel.isNotEmpty()) {
                            val f = File(out, rel)
                            if (!f.canonicalPath.startsWith(out.canonicalPath)) throw SecurityException("bad zip")
                            if (e.isDirectory) f.mkdirs()
                            else { f.parentFile?.mkdirs(); f.outputStream().use { o -> z.copyTo(o) } }
                        }
                        e = z.nextEntry
                    }
                }
            }
            val ok = File(dir, "gemma.task").exists() && File(dir, "vosk-model").exists()
            Bus.status(if (ok) "Imported. Both files ready. Turn on the switch." else "Imported. Now import the other file.")
        } catch (ex: Exception) { Bus.status("Import error: ${ex.message}") }
    }
}
