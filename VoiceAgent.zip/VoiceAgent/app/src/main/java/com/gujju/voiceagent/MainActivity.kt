package com.gujju.voiceagent

import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import java.util.zip.ZipInputStream
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

/**
 * Fully offline voice agent:  mic -> Vosk (STT) -> Gemma (LLM) -> Android TTS.
 *
 * Put these in  /sdcard/Android/data/com.gujju.voiceagent/files/ :
 *   vosk-model/   (unzipped Vosk model folder, renamed to "vosk-model")
 *   gemma.task    (Gemma 3 1B int4 .task file for MediaPipe)
 */
class MainActivity : AppCompatActivity(), RecognitionListener {

    private val worker = Executors.newSingleThreadExecutor()
    private var speech: SpeechService? = null
    private var llm: LlmInference? = null
    private var voskModel: Model? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var micBtn: Button
    private lateinit var handsFree: Switch
    private var busy = false

    private val pickGemma = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { importFile(it, false) } }
    private val pickVosk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { importFile(it, true) } }

    private enum class Mode { IDLE, WAKE, COMMAND }
    private var mode = Mode.IDLE
    /** Wake phrase. Must use words that exist in the Vosk model vocabulary
     *  (a made-up name like "gujju" is usually NOT in it). */
    private val WAKE = "hey assistant"
    private lateinit var commands: Commands

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        commands = Commands(this) { i -> runOnUiThread { try { startActivity(i) } catch (_: Exception) {} } }
        tts = TextToSpeech(this) { ttsReady = it == TextToSpeech.SUCCESS }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { afterSpeaking() }
            override fun onDone(id: String?) { afterSpeaking() }
        })
        if (hasMic()) loadModels()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    // ---------- UI (no XML needed) ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40)
        }
        status = TextView(this).apply { textSize = 16f; text = "Starting…" }
        scroll = ScrollView(this)
        log = TextView(this).apply { textSize = 15f }
        scroll.addView(log)
        handsFree = Switch(this).apply {
            text = "Wake word: say \"hey assistant\""
            setOnCheckedChangeListener { _, on ->
                if (on && voskModel != null && !busy) startWake()
                else if (!on && mode == Mode.WAKE) stopSpeech()
            }
        }
        micBtn = Button(this).apply {
            text = "🎤  Tap to talk"; isEnabled = false
            setOnClickListener { startCommand() }
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "1. Import Gemma file (.task)"
            setOnClickListener { pickGemma.launch(arrayOf("*/*")) }
        })
        root.addView(Button(this).apply {
            text = "2. Import Vosk model (.zip)"
            setOnClickListener { pickVosk.launch(arrayOf("*/*")) }
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(handsFree)
        root.addView(micBtn, LinearLayout.LayoutParams(-1, -2).apply { gravity = Gravity.CENTER })
        setContentView(root)
    }

    private fun say(who: String, msg: String) = runOnUiThread {
        log.append("$who: $msg\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
    private fun setStatus(s: String) = runOnUiThread { status.text = s }

    // ---------- Load models (background) ----------
    private fun hasMic() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (hasMic()) loadModels() else setStatus("Microphone permission needed")
    }

    private fun loadModels() = worker.execute {
        llm?.close(); llm = null; voskModel?.close(); voskModel = null
        runOnUiThread { micBtn.isEnabled = false }
        val dir = getExternalFilesDir(null)!!
        val voskDir = File(dir, "vosk-model")
        val gemma = File(dir, "gemma.task")
        if (!voskDir.exists() || !gemma.exists()) {
            setStatus("Models missing. Tap the two Import buttons above and pick your downloaded files.")
            return@execute
        }
        try {
            setStatus("Loading speech model…")
            voskModel = Model(voskDir.absolutePath)
            setStatus("Loading language model (30-60 s first time)…")
            val opts = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(gemma.absolutePath)
                .setMaxTokens(384)
                .build()
            llm = LlmInference.createFromOptions(this, opts)
            setStatus("Ready — offline")
            runOnUiThread { micBtn.isEnabled = true }
        } catch (e: Exception) {
            setStatus("Load error: ${e.message}")
        }
    }

    // ---------- Import models from Downloads (no special permission needed) ----------
    private fun importFile(uri: Uri, isVosk: Boolean) = worker.execute {
        val dir = getExternalFilesDir(null)!!
        try {
            if (!isVosk) {
                setStatus("Copying Gemma file… please wait")
                val tmp = File(dir, "gemma.tmp")
                contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                File(dir, "gemma.task").delete()
                tmp.renameTo(File(dir, "gemma.task"))
            } else {
                setStatus("Unpacking speech model…")
                val out = File(dir, "vosk-model"); out.deleteRecursively(); out.mkdirs()
                ZipInputStream(contentResolver.openInputStream(uri)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val rel = e.name.substringAfter('/', "")
                        if (rel.isNotEmpty()) {
                            val f = File(out, rel)
                            if (!f.canonicalPath.startsWith(out.canonicalPath)) throw SecurityException("bad zip")
                            if (e.isDirectory) f.mkdirs()
                            else { f.parentFile?.mkdirs(); f.outputStream().use { o -> z.copyTo(o) } }
                        }
                        e = z.nextEntry
                    }
                }
            }
            loadModels()
        } catch (ex: Exception) { setStatus("Import error: ${ex.message}") }
    }

    // ---------- Listen ----------
    private fun stopSpeech() { speech?.stop(); speech?.shutdown(); speech = null; mode = Mode.IDLE; setStatus("Ready — offline") }

    /** Always-on, tiny grammar: only listens for the wake phrase (very light on CPU/RAM). */
    private fun startWake() {
        val m = voskModel ?: return
        speech?.stop(); speech?.shutdown()
        mode = Mode.WAKE
        val grammar = "[\"$WAKE\", \"[unk]\"]"
        speech = SpeechService(Recognizer(m, 16000f, grammar), 16000f).also { it.startListening(this) }
        setStatus("Waiting for \"$WAKE\"…")
    }

    /** Full-vocabulary listening for one command (8 s timeout). */
    private fun startCommand() {
        val m = voskModel ?: return
        if (busy) return
        speech?.stop(); speech?.shutdown()
        mode = Mode.COMMAND
        ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        speech = SpeechService(Recognizer(m, 16000f), 16000f).also { it.startListening(this, 8000) }
        setStatus("Listening…")
    }

    private fun heardWake(text: String) {
        if (mode == Mode.WAKE && WAKE in text) startCommand()
    }

    override fun onPartialResult(hypothesis: String?) {
        if (mode != Mode.WAKE) return
        heardWake(JSONObject(hypothesis ?: return).optString("partial"))
    }

    override fun onResult(hypothesis: String?) {
        val j = JSONObject(hypothesis ?: return)
        val text = j.optString("text").trim()
        when (mode) {
            Mode.WAKE -> heardWake(text)
            Mode.COMMAND -> {
                if (text.isEmpty() || busy) return
                busy = true
                speech?.stop(); speech?.shutdown(); speech = null
                mode = Mode.IDLE
                say("You", text)
                setStatus("Thinking…")
                worker.execute { respond(text) }
            }
            Mode.IDLE -> {}
        }
    }
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(e: Exception?) { setStatus("Mic error: ${e?.message}") }
    override fun onTimeout() {
        speech?.shutdown(); speech = null; mode = Mode.IDLE
        if (handsFree.isChecked) startWake() else setStatus("Ready — offline")
    }

    // ---------- Think ----------
    private fun respond(userText: String) {
        val reply = commands.handle(userText) ?: try {
            val prompt = "<start_of_turn>user\n" +
                "You are a helpful voice assistant. Answer in 1-3 short spoken sentences, " +
                "no markdown. Reply in the same language the user used.\n\n" +
                "$userText<end_of_turn>\n<start_of_turn>model\n"
            llm!!.generateResponse(prompt).trim()
        } catch (e: Exception) { "Sorry, something went wrong." }
        say("Agent", reply)
        speak(reply)
    }

    // ---------- Speak ----------
    private fun speak(text: String) {
        if (!ttsReady) { afterSpeaking(); return }
        val hindi = text.any { it in '\u0900'..'\u097F' }
        tts.language = if (hindi) Locale("hi", "IN") else Locale.US
        setStatus("Speaking…")
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply")
    }

    private fun afterSpeaking() {
        busy = false
        runOnUiThread {
            setStatus("Ready — offline")
            if (handsFree.isChecked) startWake()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speech?.shutdown(); tts.shutdown(); llm?.close(); voskModel?.close()
    }
}
