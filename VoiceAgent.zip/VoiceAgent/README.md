# Offline Voice Agent (Android, 4 GB RAM friendly)

mic -> Vosk (speech-to-text) -> Gemma 3 1B (LLM) -> Android TTS. No internet needed after setup.

## 1. Get the model files (one time, needs internet)
- Vosk: https://alphacephei.com/vosk/models
  - English: vosk-model-small-en-us-0.15
  - Hindi:   vosk-model-small-hi-0.22
  Unzip and rename the folder to `vosk-model`.
- Gemma 3 1B (int4 .task for MediaPipe), from Hugging Face litert-community
  (accept the Gemma license). Rename the file to `gemma.task`.

## 2. Build
Open this folder in Android Studio -> let Gradle sync -> Run on your phone (USB debugging).

## 3. Copy models to the phone
Put `vosk-model/` and `gemma.task` into:
  /sdcard/Android/data/com.gujju.voiceagent/files/
(Run the app once first so the folder exists. Or: adb push gemma.task <that path>.)

## 4. Offline voices
Settings -> System -> Languages -> Text-to-speech -> download English/Hindi voice data.

## Tips
- Switching language: swap the `vosk-model` folder (en <-> hi).
- If it lags or crashes: use a smaller Gemma/Qwen 0.5B .task, close other apps.
- Add your own commands in `handleCommand()` in MainActivity.kt.

## New: wake word + commands
- Turn on the switch, then say **"hey assistant"** -> beep -> speak your command.
- The wake phrase is `WAKE` in MainActivity.kt. Use common words (they must exist in the Vosk model;
  a made-up name like "Gujju" usually won't be recognised).
- Commands (English, in Commands.kt): "set an alarm for seven thirty a m", "set a timer for five minutes",
  "note that buy milk", "read my notes", "clear my notes", "what time is it".
- Everything else goes to Gemma. Add more commands in `Commands.handle()`.
- Always-listening uses battery; turn the switch off when not needed.

## Phone-only route (GitHub builds the APK)
1. Upload VoiceAgent.zip to a new GitHub repo.
2. Create .github/workflows/build.yml (text given in chat). It unzips and builds automatically.
3. Download the APK from the Actions run, install it.
4. Download Vosk .zip + Gemma .task into Downloads, then tap the two Import buttons in the app.

## Background mode (v2)
The agent now runs as a foreground service (notification "Voice Agent is listening"), so it hears
"hey assistant" with the app closed or screen off. Turn on the "Always listening" switch.
Set Settings > Apps > Voice Agent > Battery > Unrestricted so Android doesn't kill it.
Alarms/timers may be blocked by Android when the app is closed; notes, time and chat work.
A fixed debug.keystore is included so future builds install over the old one.

## v3: open apps + call contacts
- "open whatsapp" / "launch camera"; "call <contact name>" -> "Call X? Say yes" -> "yes".
- In the app: tap button 3 (contacts + phone permission) and button 4 (display over other apps,
  needed so Android lets the background service open apps/alarms).
